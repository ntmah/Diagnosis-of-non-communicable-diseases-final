export const patientList = [
  { id: 1, name: "Nguyễn Văn A", date: "17/07/2025", type: "Tiểu đường" },
  { id: 2, name: "Trần Thị B", date: "17/07/2025", type: "Tăng huyết áp" },
  { id: 3, name: "Lê Văn C", date: "15/07/2025", type: "Tiểu đường" },
  { id: 4, name: "Phạm Thị D", date: "16/07/2025", type: "Tăng huyết áp" },
];
